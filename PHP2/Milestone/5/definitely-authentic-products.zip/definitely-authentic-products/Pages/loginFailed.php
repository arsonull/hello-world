<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Login Failed</title>
</head>
<body>
	<h2 style="color: #ee5500;"> Login failed: <?php echo " " . $message ;?></h2><br>
</body>
</html>
